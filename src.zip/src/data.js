export const quizData = [
  {
    title: "Which 'Friends' Character Are You?",
    description: "Find out which friend matches your vibe.",
  },
  {
    title: "Star Wars Personality Quiz",
    description: "Discover your galactic alter ego.",
  },
];
