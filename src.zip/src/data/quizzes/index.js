import starWarsQuiz from "./star-wars";

const quizzes = {
  "star-wars": starWarsQuiz,
  // Add more quizzes here later
};

export default quizzes;
